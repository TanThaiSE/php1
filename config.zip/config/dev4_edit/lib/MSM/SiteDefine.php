<?php
/**
 * サイト定義
 *
 * サイト定義
 * (フィルタ関連の設定はConstFilter.phpを参照)
 *
 * @package MSM
 * @author sumoto
 * @version $Id: SiteDefine.php.tmpl 18321 2011-07-23 11:17:00Z etsu $
 */
 
/**
 * サイトのルートディレクトリ
 */
define('SITE_ROOT_DIR', '/home/publis/publis');

/**
 * バックアップディレクトリ
 */
define('BACKUP_DIR', '/home/publis/publis/backup');

/**
 * キャッシュディレクトリ
 */
define('CACHE_DIR', '/home/publis/publis/cache');

/**
 * スタティックディレクトリ
 */
define('STATIC_DIR', '');

/**
 * データベースホスト
 */
define('DB_HOST', '172.17.196.161');

/**
 * データベースポート
 */
define('DB_PORT', '5432');

/**
 * データベース名（またはTNSサービス名）
 */
define('DB_NAME', 'publis');

/**
 * データベースのユーザー名
 */
define('DB_USER', 'publis');

/**
 * データベースのパスワード
 */
define('DB_PASSWORD', 'publis');

/**
 * ライブラリファイルバッチアップロードのディレクトリ
 */
define('LIBRARY_BATCH_DIR', '/home/publis/publis/batch');

/**
 * URLリダイレクト機能フラグ
 * (空文字：無効、空文字以外：有効)
 * ※指定文字列は、Apache設定のRewriteMap名
 */
define('MAP_PUBLIS', '');

/**
 * エイリアスベース
 */
define('ALIAS_BASE', '/');

/**
 * デバッグモード
 */
define('DEBUG_MODE', 1);

/**
 * スタティックフラグ
 */
define('STATIC_FLAG', 1);

/**
 * Memcachedフラグ
 */
define('MEMCACHED_FLAG', 0);

/**
 * セッション情報ＤＢ保存
 */
/* %%STATIC_OUT%%
// セッション情報用ユーザー
define('SESSION_DB_USER', '');

// セッション情報用パスワード
define('SESSION_DB_PASSWORD', '');

//// セッションの格納にCMSと別のDBを使用する場合指定する
//// SESSION_DB_HOST, SESSION_DB_PORT, SESSION_DB_NAME の3つとも定義しないと動作しない
// セッション情報用ホスト
//define('SESSION_DB_HOST', 'localhost');
// セッション情報用ポート
//define('SESSION_DB_PORT', '');
// セッション情報用データベース名
//define('SESSION_DB_NAME', 'etsu_publis');

require_once 'MSM/SessionMemcached.php';
MSM_Session_Manager::initialize();
//require_once 'MSM/SessionDB.php';

// セッション関数のセット
//if( MEMCACHED_FLAG && MSM_SessionMemcached::isEnabled() ) {
//	MSM_SessionMemcached::initialize();
//} else {
//	MSM_SessionDB::registerHandler();
//}
%%STATIC_OUT%% */

// クライアント制限フラグ
// 1:SSLクライアント認証
define('CLIENT_LIMIT_FLAG', 0);

// 問い合わせ関連
// 問い合わせの情報をデータベースに保存設定
// 0:保存する, 1:保存しない
define('QUERY_DO_NOT_SAVE_IN_DB', 0);

/////////////////////////////////////
// 追加 PHP 動作設定
/////////////////////////////////////
// デバックモード時以外は、エラー出力を無効
// ※前提として.htaccessにて、エラー出力を有効化しています。
if (DEBUG_MODE!=1) ini_set('display_errors', false);

// プロトコル変更処理時のポート番号(初期値 HTTPS:443, HTTP:80)
define('REDIRECT_HTTPS_PORT', '443');
define('REDIRECT_HTTP_PORT', '80');

// マルチDB対応
define('DB_TYPE', 'PostgreSQL');
define('DB_STMT_TYPE', 'PDO');
define('DB_SQL_TYPE', 'PostgreSQL');

// システム管理画面のSSL有効フラグ
// 0:無効, 1:有効
define('SYSTEM_MANAGE_SSL_FLAG', 0);

// PUBLIS ASPのモード設定
// 0:無効, 1:ASP エントリー, 2:ASP スタンダード
define('ASP_MODE', 0);

// CLOSE CURSORモード
define('CLOSE_CURSOR_MODE', 1);

// スキン名
define('SKIN_NAME', '');

// セッションID引き回し不可設定
define('SESSION_ID_UNNECESSARY', 1);

// temmplate dump上限
define('TEMPLATE_DUMP_NUM_LIMIT', 9999999);

//----------------------------------------------------------------
// DBチェックフラグ ()
// 0:無効, 1:有効
define('CHECKDB_FLAG', 1);
//----------------------------------------------------------------

?>
