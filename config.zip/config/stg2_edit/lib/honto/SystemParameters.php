<?php
/**
 * システムパラメータ 【2.0/IDC_STG2】
 * @author gen
 *
 * 生成日：2012/09/03 17:39:39
 */
class SystemParameters {


    /** フロント *****************************************************************************************************************/

    /** Ｍｅｄｉａサーバ共有パス */
    const MEDIA_SERVER_AREA_PATH = '/image';

    /** 携帯端末VGA判定しきい値 */
    const VGA_THRESHOLD_SIZE = '460';

    /** Ｍｅｄｉａサーバホスト名 */
    const MEDIA_SERVER_HOSTNAME = 'image.stg2.honto.jp';

    /** SITE PUBLIS上の画像ファイル格納ディレクトリ（PC） */
    const CMN_IMG_DIR_PC = '/library/img/pc/';

    /** SITE PUBLIS上の画像ファイル格納ディレクトリ（MB） */
    const CMN_IMG_DIR_MB = '/library/img/mb/';

    /** SITE PUBLIS上の画像ファイル格納ディレクトリ（SP） */
    const CMN_IMG_DIR_SP = '/library/img/sp/';

    /** Hontoサーバホスト名 */
    const HONTO_SERVER_HOSTNAME = 'stg2.honto.jp';

    /** ユーザ識別ID期限（日数） */
    const PSID_DUE_DATE = '90';

    /** トラッキングID期限（日数） */
    const TRID_DUE_DATE = '4000';

    /** 空メール送信先（モバイル会員新規登録） */
    const MEM_MB_MEM_REG_BLANK_MAIL_TO = 'reg2@srs-a.m.stg.honto.jp';

    /** 空メール送信先（モバイルメールアドレス変更） */
    const MEM_MB_MAIL_CHG_BLANK_MAIL_TO = 'chg2@srs-a.m.stg.honto.jp';

    /** マイ店舗表示最大件数 */
    const MEM_MY_STO_DSP_MAXNUM = '5';

    /** PHP（SITE PUBLISプラグイン）からJavaのリソースサービスを呼び出す際の共通URI */
    const REST_SERVICE_BASE_URI = 'http://appserver:8080/api';

    /** テスト向け検証デバイス環境設定ファイル */
    const REVIEW_DEVICE_PROPERTIES = '/home/publis/publis/lib/env/review_device.properties';

    /** 検索エンジンアクセス先 */
    const PRD_SERCH_ENGINE_ACCESS_PATH = 'http://172.17.192.78:15200/search';

    /** サイトカタリストパラメータ出力除外項目リスト（PC） */
    const ETC_SITE_CATALYST_EXCLUSION_LST_PC = '';

    /** サイトカタリストパラメータ出力除外項目リスト（SP） */
    const ETC_SITE_CATALYST_EXCLUSION_LST_SP = '';

    /** サイトカタリストパラメータ出力除外項目リスト（MB） */
    const ETC_SITE_CATALYST_EXCLUSION_LST_MB = '';

    /** コンテンツダウンロードURL(T-Time Plugin) */
    const CONT_DL_URL_T_TIME_PLUGIN = 'https://dl.stg2.honto.jp/download/downloadSampleContentsForTTime';

    /** 注文履歴一覧最大表示件数（PC） */
    const ORD_PC_HISTORY_LIST_PAR_PAGE = '10';

    /** 注文履歴一覧最大表示件数（SP） */
    const ORD_SP_HISTORY_LIST_PAR_PAGE = '10';

    /** 注文履歴一覧最大表示件数（MB） */
    const ORD_MB_HISTORY_LIST_PAR_PAGE = '10';

    /** 買い物カゴ(電子書籍)1ページあたりの表示件数(専用端末対応) */
    const ORD_SPGCT_DISP_NUM = '10';

    /** アコーディオン情報の最大表示桁数 */
    const ORD_SP_MAX_COLUMN_ACCORDION = '15';

    /** T-TimeCrochet関連ファイルパス */
    const T_TIME_CROCHET_PATH = '/opt/T-TimeCrochet/';

    /** iコレクト決済 リンク */
    const ORD_ICOL_STL_LINK = 'http://help.honto.jp/mb/faq_detail.html?id=20064&page=2';

    /** サムネイル用電子書籍サーバパス */
    const THUMBNAIL_IMAGE_SERVER_PATH = 'http://dl.stg2.honto.jp/';

    /** サイトカタリスト送付パラメータ変数名（s.events） */
    const ETC_CATALYST_PROP_NM_S_EVENTS = 's.events';

    /** サイトカタリスト送付パラメータ変数名（s.hier1） */
    const ETC_CATALYST_PROP_NM_S_HIER1 = 's.hier1';

    /** サイトカタリスト送付パラメータ変数名（s.hier2） */
    const ETC_CATALYST_PROP_NM_S_HIER2 = 's.hier2';

    /** サイトカタリスト送付パラメータ変数名（s.hier3） */
    const ETC_CATALYST_PROP_NM_S_HIER3 = 's.hier3';

    /** サイトカタリスト送付パラメータ変数名（s.hier4） */
    const ETC_CATALYST_PROP_NM_S_HIER4 = 's.hier4';

    /** サイトカタリスト送付パラメータ変数名（s.hier5） */
    const ETC_CATALYST_PROP_NM_S_HIER5 = 's.hier5';

    /** サイトカタリスト送付パラメータ変数名（s.pageName） */
    const ETC_CATALYST_PROP_NM_S_PAGENAME = 's.pageName';

    /** サイトカタリスト送付パラメータ変数名（s.server） */
    const ETC_CATALYST_PROP_NM_S_SERVER = 's.server';

    /** サイトカタリスト送付パラメータ変数名（s.pageType） */
    const ETC_CATALYST_PROP_NM_S_PAGETYPE = 's.pageType';

    /** サイトカタリスト送付パラメータ変数名（s.state） */
    const ETC_CATALYST_PROP_NM_S_STATE = 's.state';

    /** サイトカタリスト送付パラメータ変数名（s.zip） */
    const ETC_CATALYST_PROP_NM_S_ZIP = 's.zip';

    /** サイトカタリスト送付パラメータ変数名（s.prop1） */
    const ETC_CATALYST_PROP_NM_S_PROP1 = 's.prop1';

    /** サイトカタリスト送付パラメータ変数名（s.prop2） */
    const ETC_CATALYST_PROP_NM_S_PROP2 = 's.prop2';

    /** サイトカタリスト送付パラメータ変数名（s.prop3） */
    const ETC_CATALYST_PROP_NM_S_PROP3 = 's.prop3';

    /** サイトカタリスト送付パラメータ変数名（s.prop4） */
    const ETC_CATALYST_PROP_NM_S_PROP4 = 's.prop4';

    /** サイトカタリスト送付パラメータ変数名（s.prop5） */
    const ETC_CATALYST_PROP_NM_S_PROP5 = 's.prop5';

    /** サイトカタリスト送付パラメータ変数名（s.prop6） */
    const ETC_CATALYST_PROP_NM_S_PROP6 = 's.prop6';

    /** サイトカタリスト送付パラメータ変数名（s.prop7） */
    const ETC_CATALYST_PROP_NM_S_PROP7 = 's.prop7';

    /** サイトカタリスト送付パラメータ変数名（s.prop8） */
    const ETC_CATALYST_PROP_NM_S_PROP8 = 's.prop8';

    /** サイトカタリスト送付パラメータ変数名（s.prop9） */
    const ETC_CATALYST_PROP_NM_S_PROP9 = 's.prop9';

    /** サイトカタリスト送付パラメータ変数名（s.prop10） */
    const ETC_CATALYST_PROP_NM_S_PROP10 = 's.prop10';

    /** サイトカタリスト送付パラメータ変数名（s.prop11） */
    const ETC_CATALYST_PROP_NM_S_PROP11 = 's.prop11';

    /** サイトカタリスト送付パラメータ変数名（s.prop12） */
    const ETC_CATALYST_PROP_NM_S_PROP12 = 's.prop12';

    /** サイトカタリスト送付パラメータ変数名（s.prop13） */
    const ETC_CATALYST_PROP_NM_S_PROP13 = 's.prop13';

    /** サイトカタリスト送付パラメータ変数名（s.prop14） */
    const ETC_CATALYST_PROP_NM_S_PROP14 = 's.prop14';

    /** サイトカタリスト送付パラメータ変数名（s.prop15） */
    const ETC_CATALYST_PROP_NM_S_PROP15 = 's.prop15';

    /** サイトカタリスト送付パラメータ変数名（s.prop16） */
    const ETC_CATALYST_PROP_NM_S_PROP16 = 's.prop16';

    /** サイトカタリスト送付パラメータ変数名（s.prop17） */
    const ETC_CATALYST_PROP_NM_S_PROP17 = 's.prop17';

    /** サイトカタリスト送付パラメータ変数名（s.prop18） */
    const ETC_CATALYST_PROP_NM_S_PROP18 = 's.prop18';

    /** サイトカタリスト送付パラメータ変数名（s.prop19） */
    const ETC_CATALYST_PROP_NM_S_PROP19 = 's.prop19';

    /** サイトカタリスト送付パラメータ変数名（s.prop20） */
    const ETC_CATALYST_PROP_NM_S_PROP20 = 's.prop20';

    /** サイトカタリスト送付パラメータ変数名（s.prop21） */
    const ETC_CATALYST_PROP_NM_S_PROP21 = 's.prop21';

    /** サイトカタリスト送付パラメータ変数名（s.prop22） */
    const ETC_CATALYST_PROP_NM_S_PROP22 = 's.prop22';

    /** サイトカタリスト送付パラメータ変数名（s.prop23） */
    const ETC_CATALYST_PROP_NM_S_PROP23 = 's.prop23';

    /** サイトカタリスト送付パラメータ変数名（s.prop24） */
    const ETC_CATALYST_PROP_NM_S_PROP24 = 's.prop24';

    /** サイトカタリスト送付パラメータ変数名（s.prop25） */
    const ETC_CATALYST_PROP_NM_S_PROP25 = 's.prop25';

    /** サイトカタリスト送付パラメータ変数名（s.prop26） */
    const ETC_CATALYST_PROP_NM_S_PROP26 = 's.prop26';

    /** サイトカタリスト送付パラメータ変数名（s.prop27） */
    const ETC_CATALYST_PROP_NM_S_PROP27 = 's.prop27';

    /** サイトカタリスト送付パラメータ変数名（s.prop28） */
    const ETC_CATALYST_PROP_NM_S_PROP28 = 's.prop28';

    /** サイトカタリスト送付パラメータ変数名（s.prop29） */
    const ETC_CATALYST_PROP_NM_S_PROP29 = 's.prop29';

    /** サイトカタリスト送付パラメータ変数名（s.prop30） */
    const ETC_CATALYST_PROP_NM_S_PROP30 = 's.prop30';

    /** サイトカタリスト送付パラメータ変数名（s.prop31） */
    const ETC_CATALYST_PROP_NM_S_PROP31 = 's.prop31';

    /** サイトカタリスト送付パラメータ変数名（s.prop32） */
    const ETC_CATALYST_PROP_NM_S_PROP32 = 's.prop32';

    /** サイトカタリスト送付パラメータ変数名（s.prop33） */
    const ETC_CATALYST_PROP_NM_S_PROP33 = 's.prop33';

    /** サイトカタリスト送付パラメータ変数名（s.prop34） */
    const ETC_CATALYST_PROP_NM_S_PROP34 = 's.prop34';

    /** サイトカタリスト送付パラメータ変数名（s.prop35） */
    const ETC_CATALYST_PROP_NM_S_PROP35 = 's.prop35';

    /** サイトカタリスト送付パラメータ変数名（s.prop36） */
    const ETC_CATALYST_PROP_NM_S_PROP36 = 's.prop36';

    /** サイトカタリスト送付パラメータ変数名（s.prop37） */
    const ETC_CATALYST_PROP_NM_S_PROP37 = 's.prop37';

    /** サイトカタリスト送付パラメータ変数名（s.prop38） */
    const ETC_CATALYST_PROP_NM_S_PROP38 = 's.prop38';

    /** サイトカタリスト送付パラメータ変数名（s.prop39） */
    const ETC_CATALYST_PROP_NM_S_PROP39 = 's.prop39';

    /** サイトカタリスト送付パラメータ変数名（s.prop40） */
    const ETC_CATALYST_PROP_NM_S_PROP40 = 's.prop40';

    /** サイトカタリスト送付パラメータ変数名（s.prop41） */
    const ETC_CATALYST_PROP_NM_S_PROP41 = 's.prop41';

    /** サイトカタリスト送付パラメータ変数名（s.prop51） */
    const ETC_CATALYST_PROP_NM_S_PROP51 = 's.prop51';

    /** サイトカタリスト送付パラメータ変数名（s.prop52） */
    const ETC_CATALYST_PROP_NM_S_PROP52 = 's.prop52';

    /** サイトカタリスト送付パラメータ変数名（s.prop53） */
    const ETC_CATALYST_PROP_NM_S_PROP53 = 's.prop53';

    /** サイトカタリスト送付パラメータ変数名（s.prop54） */
    const ETC_CATALYST_PROP_NM_S_PROP54 = 's.prop54';

    /** サイトカタリスト送付パラメータ変数名（s.prop55） */
    const ETC_CATALYST_PROP_NM_S_PROP55 = 's.prop55';

    /** サイトカタリスト送付パラメータ変数名（products） */
    const ETC_CATALYST_PROP_NM_PRODUCTS = 's.products';

    /** サイトカタリスト送付パラメータ変数名（s.purchaseID） */
    const ETC_CATALYST_PROP_NM_S_PURCHASEID = 's.purchaseID';

    /** サイトカタリスト送付パラメータ変数名（s.campaign） */
    const ETC_CATALYST_PROP_NM_S_CAMPAIGN = 's.campaign';

    /** サイトカタリストイベント変数名（prodView） */
    const ETC_CATALYST_EVENT_NM_PRODVIEW = 'prodView';

    /** サイトカタリストイベント変数名（event1） */
    const ETC_CATALYST_EVENT_NM_EVENT1 = 'event1';

    /** サイトカタリストイベント変数名（scOpen） */
    const ETC_CATALYST_EVENT_NM_SCOPEN = 'scOpen';

    /** サイトカタリストイベント変数名（scAdd） */
    const ETC_CATALYST_EVENT_NM_SCADD = 'scAdd';

    /** サイトカタリストイベント変数名（scView） */
    const ETC_CATALYST_EVENT_NM_SCVIEW = 'scView';

    /** サイトカタリストイベント変数名（scCheckout） */
    const ETC_CATALYST_EVENT_NM_SCCHECKOUT = 'scCheckout';

    /** サイトカタリストイベント変数名（event2） */
    const ETC_CATALYST_EVENT_NM_EVENT2 = 'event2';

    /** サイトカタリストイベント変数名（event3） */
    const ETC_CATALYST_EVENT_NM_EVENT3 = 'event3';

    /** サイトカタリストイベント変数名（event4） */
    const ETC_CATALYST_EVENT_NM_EVENT4 = 'event4';

    /** サイトカタリストイベント変数名（purchase） */
    const ETC_CATALYST_EVENT_NM_PURCHASE = 'purchase';

    /** サイトカタリストイベント変数名（event5） */
    const ETC_CATALYST_EVENT_NM_EVENT5 = 'event5';

    /** サイトカタリストイベント変数名（event6） */
    const ETC_CATALYST_EVENT_NM_EVENT6 = 'event6';

    /** サイトカタリストイベント変数名（event7） */
    const ETC_CATALYST_EVENT_NM_EVENT7 = 'event7';

    /** サイトカタリストイベント変数名（event8） */
    const ETC_CATALYST_EVENT_NM_EVENT8 = 'event8';

    /** サイトカタリストイベント変数名（event9） */
    const ETC_CATALYST_EVENT_NM_EVENT9 = 'event9';

    /** サイトカタリストイベント変数名（event10） */
    const ETC_CATALYST_EVENT_NM_EVENT10 = 'event10';

    /** サイトカタリストイベント変数名（event11） */
    const ETC_CATALYST_EVENT_NM_EVENT11 = 'event11';

    /** サイトカタリストイベント変数名（event12） */
    const ETC_CATALYST_EVENT_NM_EVENT12 = 'event12';

    /** サイトカタリストイベント変数名（event13） */
    const ETC_CATALYST_EVENT_NM_EVENT13 = 'event13';

    /** サイトカタリストイベント変数名（event14） */
    const ETC_CATALYST_EVENT_NM_EVENT14 = 'event14';

    /** サイトカタリストイベント変数名（event15） */
    const ETC_CATALYST_EVENT_NM_EVENT15 = 'event15';

    /** サイトカタリストイベント変数名（event16） */
    const ETC_CATALYST_EVENT_NM_EVENT16 = 'event16';

    /** サイトカタリストイベント変数名（event17） */
    const ETC_CATALYST_EVENT_NM_EVENT17 = 'event17';

    /** サイトカタリストイベント変数名（event18） */
    const ETC_CATALYST_EVENT_NM_EVENT18 = 'event18';

    /** サイトカタリストイベント変数名（event19） */
    const ETC_CATALYST_EVENT_NM_EVENT19 = 'event19';

    /** サイトカタリストイベント変数名（event20） */
    const ETC_CATALYST_EVENT_NM_EVENT20 = 'event20';

    /** サイトカタリストイベント変数名（event21） */
    const ETC_CATALYST_EVENT_NM_EVENT21 = 'event21';

    /** サイトカタリストイベント変数名（event22） */
    const ETC_CATALYST_EVENT_NM_EVENT22 = 'event22';

    /** サイトカタリストイベント変数名（event23） */
    const ETC_CATALYST_EVENT_NM_EVENT23 = 'event23';

    /** サイトカタリストイベント変数名（event24） */
    const ETC_CATALYST_EVENT_NM_EVENT24 = 'event24';

    /** サイトカタリストイベント変数名（event25） */
    const ETC_CATALYST_EVENT_NM_EVENT25 = 'event25';

    /** サイトカタリストイベント変数名（event26） */
    const ETC_CATALYST_EVENT_NM_EVENT26 = 'event26';

    /** サイトカタリストイベント変数名（event27） */
    const ETC_CATALYST_EVENT_NM_EVENT27 = 'event27';

    /** サイトカタリストイベント変数名（event28） */
    const ETC_CATALYST_EVENT_NM_EVENT28 = 'event28';

    /** サイトカタリスト送付パラメータ変数名（eVar50） */
    const ETC_CATALYST_PROP_NM_EVAR50 = 's.eVar50';

    /** サンプルメール説明文ディレクトリ */
    const MEM_MEDIA_MAIL_SAMPLE_DIR = '/nas/media01/mail_sample_img';

    /** FAST検索可能件数最大値 */
    const FAST_SEARCH_COUNT_MAX = '4020';

    /** サイトカタリストイベント変数設定スクリプト文字列(event13) */
    const ETC_CATALYST_EVENT_SCRIPT_EVENT13 = 's_click(\'event13\')';

    /** サイトカタリストイベント変数設定スクリプト文字列(event14) */
    const ETC_CATALYST_EVENT_SCRIPT_EVENT14 = 's_click(\'event14\')';

    /** サイトカタリストイベント変数設定スクリプト文字列(event15) */
    const ETC_CATALYST_EVENT_SCRIPT_EVENT15 = 's_click(\'event15\')';

    /** サイトカタリストイベント変数設定スクリプト文字列(event24) */
    const ETC_CATALYST_EVENT_SCRIPT_EVENT24 = 's_click(\'event24\')';

    /** リソース呼び出しタイムアウト値 */
    const REST_SERVICE_TIMEOUT = '600';

    /** 商品検索結果表示件数最大値 */
    const PRD_SEARCH_RESULT_MAX_HIT = '10000';

    /** 価格桁あふれ時表示文字列 */
    const ORD_PRICE_OVERFLOW_STRING = '-';

    /** 商品画像（書影）のパス */
    const ITEM_IMAGE_BASE_DIR = 'item';

    /** トークンエラー遷移先URL定義キー(MR_00_001) */
    const ETC_ERTK_MR_00_001 = '1001';

    /** トークンエラー遷移先URL定義キー(LI_00_002) */
    const ETC_ERTK_LI_00_002 = '1002';

    /** トークンエラー遷移先URL定義キー(LI_00_001) */
    const ETC_ERTK_LI_00_001 = '1003';

    /** トークンエラー遷移先URL定義キー(DT_00_009) */
    const ETC_ERTK_DT_00_009 = '1004';

    /** トークンエラー遷移先URL定義キー(AC_01_002) */
    const ETC_ERTK_AC_01_002 = '1005';

    /** トークンエラー遷移先URL定義キー(AC_02_001) */
    const ETC_ERTK_AC_02_001 = '1006';

    /** トークンエラー遷移先URL定義キー(AC_04_001) */
    const ETC_ERTK_AC_04_001 = '1007';

    /** トークンエラー遷移先URL定義キー(AC_27_001) */
    const ETC_ERTK_AC_27_001 = '1008';

    /** トークンエラー遷移先URL定義キー(AC_03_001) */
    const ETC_ERTK_AC_03_001 = '1009';

    /** トークンエラー遷移先URL定義キー(AC_13_001) */
    const ETC_ERTK_AC_13_001 = '1010';

    /** トークンエラー遷移先URL定義キー(AC_14_002) */
    const ETC_ERTK_AC_14_002 = '1011';

    /** トークンエラー遷移先URL定義キー(AC_14_001) */
    const ETC_ERTK_AC_14_001 = '1012';

    /** トークンエラー遷移先URL定義キー(AC_15_001) */
    const ETC_ERTK_AC_15_001 = '1013';

    /** トークンエラー遷移先URL定義キー(AC_16_002) */
    const ETC_ERTK_AC_16_002 = '1014';

    /** トークンエラー遷移先URL定義キー(AC_00_001) */
    const ETC_ERTK_AC_00_001 = '1015';

    /** トークンエラー遷移先URL定義キー(AC_16_001) */
    const ETC_ERTK_AC_16_001 = '1016';

    /** トークンエラー遷移先URL定義キー(CT_00_001) */
    const ETC_ERTK_CT_00_001 = '4001';

    /** トークンエラー遷移先URL定義キー(CT_06_001) */
    const ETC_ERTK_CT_06_001 = '4002';

    /** トークンエラー遷移先URL定義キー(CT_05_001) */
    const ETC_ERTK_CT_05_001 = '4003';

    /** トークンエラー遷移先URL定義キー(CT_13_001) */
    const ETC_ERTK_CT_13_001 = '4004';

    /** トークンエラー遷移先URL定義キー(AC_05_001) */
    const ETC_ERTK_AC_05_001 = '4005';

    /** トークンエラー遷移先URL定義キー(AC_10_001) */
    const ETC_ERTK_AC_10_001 = '4006';

    /** トークンエラー遷移先URL定義キー(CS_03_001) */
    const ETC_ERTK_CS_03_001 = '5001';

    /** トークンエラー遷移先URL定義キー(TOP_00_001) */
    const ETC_ERTK_TOP_00_001 = '5002';

    /** トークンエラー遷移先URL定義キー(TOP_00_002) */
    const ETC_ERTK_TOP_00_002 = '5003';

    /** トークンエラー遷移先URL定義キー(TOP_00_003) */
    const ETC_ERTK_TOP_00_003 = '5004';

    /** sorry画面_トークンエラー時refresh秒数 */
    const ETC_ERTK_REFRESH_SECOND = '5';

    /** トークンエラー遷移先URL定義キー(CT_14_001) */
    const ETC_ERTK_CT_14_001 = '4007';

    /** ADPLANモジュールパス */
    const ETC_ADPLAN_PATH = 'honto';

    /** 端末の登録についてURL */
    const ORD_DEVICE_REGIST_HELP_URL = 'http://dev.honto.jp/faq_sample.html';

    /** リソース呼び出し接続タイムアウト時間設定 */
    const CURLOPT_CONNECTTIMEOUT_VALUE = '5';


    /** 共通 *****************************************************************************************************************/

    /** クレジットカードの有効年数 */
    const ORD_CRCRD_YEAR_MAX = '10';

    /** 注文キャンセル完了時の説明文 */
    const ORD_EXP_TXT = '';

    /** 公開系一覧MAX件数 */
    const ORD_CNS_LIST_MAXNUM = '10';

    /** 公開系一覧ページリンク表示数 */
    const ORD_CNS_LIST_LINKNUM = '10';

    /** ビューア利用方法へのリンク */
    const ORD_VWR_USE_MTD_LNK = 'http://help.honto.jp/faq_detail.html?id=10085&page=1';

    /** 税込金額表示 */
    const ORD_DISP_AMT_IN_TAX = '税込';

    /** 税抜金額表示 */
    const ORD_DISP_AMT_EX_TAX = '税抜';

    /** iTunes AppStore リンク */
    const ORD_I_TUNES_APP_STORE_LINK = 'xxxx';

    /** BOOKストア 2Dfacto アプリ */
    const ORD_BOOK_STORE_2DFACTO_LINK = 'xxxxx';


}


