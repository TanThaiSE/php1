<?php
/**
 * --------------------------------------------------------------------------
 * システム名 ：ハイブリッド書店システム
 * サブシステム名 ：AP基盤
 * 機能名 ：共通フレームワーク
 * © 2011 Dai Nippon Printing Co.,Ltd. All rights reserved.
 * --------------------------------------------------------------------------
 * @package Honto
 */
require_once 'honto/enums/MemberStatus.php';

/**
 * Memcachedの環境を定義するクラス
 * @author Auto-gen
 */
class Honto_MemcachedConfig {
    /** キャッシュ機構自体の有効/無効 */
    const ENABLE_RESOURCE_CACHE = true;

    /** キーの最小桁数（バイト数） */
    const MIN_KEY_LENGTH = 1;

    /** キーの最長桁数（バイト数） */
    const MAX_KEY_LENGTH = 250;

    /** キャッシュ削除パラメータ */
    const CACHE_CLEAR_PARAM_KEY = "cache";
    const CACHE_CLEAR_PARAM_VALUE = "clear";

    /** memcachedサーバ一覧 */
    public static $MEMCACHED_SERVERS = array(
        array('172.17.193.162', 11212, 100)
    );

    /** キャッシュ削除許可サイト */
    public static $FLUSHABLE_SITES = array(
        array('0.0.0.0', '0.0.0.0')
    );

    /** キャッシュ不可の会員区分 */
    public static $INVALID_MEMBER_CLASS = array(
        Honto_MemberStatus::DB_C_MEM_CLS_DEMO_MEMBER_INSPECTION_USE,
        Honto_MemberStatus::DB_C_MEM_CLS_DEMO_MEMBER_PUBLICATION
    );

}
