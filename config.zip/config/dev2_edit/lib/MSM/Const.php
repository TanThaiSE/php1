<?php
/**
 * 定数
 *
 * 定数です。
 *
 * @package MSM
 * @author sumoto
 * @version $Id$
 */

// umaskの設定
umask(000);

/**#@+
 * エラータイプ
 */
define('ERROR_UNKNOWN', 0);
define('ERROR_DB', 1);
define('ERROR_BLOCK', 2);
define('ERROR_PAGE', 3);
define('ERROR_PERMISSION', 4);
define('ERROR_PARAMETER', 5);
define('ERROR_NO_PAGE', 6);
define('ERROR_NO_BLOCK', 7);
define('ERROR_UNREGISTER', 8);
define('ERROR_UNPUBLISHED_PAGE', 9);
define('ERROR_FILE', 10);
define('ERROR_MAIL', 11);
define('ERROR_PERMISSION_VIEW', 12);
define('ERROR_NO_NEW_REG', 13);
define('ERROR_OVER_POST_MAX_CAUSE_NO_PARAMETER', 15);
define('ERROR_CONNECT_TOO_MANY_CLIENTS', 16);
define('ERROR_NO_CHANGE_REG', 17);
define('ERROR_NO_CHANGE_PASS', 18);
define('ERROR_HANDLE_FILE', 19);
define('ERROR_OPERATION_LOG', 20);
define('ERROR_SSL_PERMISSION', 21);
define('ERROR_UNSUPPORTED_USER_AGENT', 22);
define('ERROR_ONLY_MOBILE_LICENSE', 23);
define('ERROR_ONLY_PC_LICENSE', 24);
define('ERROR_NO_REGISTER_PAGE', 25);
define('ERROR_ONLY_SMARTPHONE_LICENSE', 26);
define('ERROR_EXTERNAL', 128);
define('ERROR_UNDEFINED', 255);

/**#@-*/

/*
// サイト設定の読み込み
$targetIncFileName = 'MSM/SiteDefine.php';
$pathIncFile = realpath('../lib/'.$targetIncFileName);
if (file_exists($pathIncFile)) {
	// 直接パス指定で存在すれば読み込み
	require_once $pathIncFile;
	require_once realpath('../lib/MSM/Date.php');
} else {
	// インクルードパス設定を展開して検索
	$arrIncPath = explode( PATH_SEPARATOR, get_include_path() );
	foreach($arrIncPath as $pathInc) {
		// インクルードパス・ディレクトリにファイルが存在すれば読み込み
		$pathIncFile = realpath($pathInc).'/'.$targetIncFileName;
		if (@file_exists($pathIncFile)){
			require_once $pathIncFile;
			break;
		}
	}
}
*/

////////////////////////////////
// Windows/IIS対応【暫定対応】
////////////////////////////////
// ISAPI_Rewrite(http://www.isapirewrite.com/)用
if ( PHP_OS=="WINNT" || PHP_OS=="WIN32" ) {
	if (preg_match('%IIS%',$_SERVER['SERVER_SOFTWARE'])	// =IIS
	&& isset($_SERVER['HTTP_X_REWRITE_URL'])
	&& $_SERVER['REQUEST_URI'] != $_SERVER['HTTP_X_REWRITE_URL']
	) {
		// REQUEST_URIをリライト前の元のリクエストURLに書き換え！
		$_SERVER['REQUEST_URI'] = $_SERVER['HTTP_X_REWRITE_URL'];
	}
}
////////////////////////////////

/**
 * プロダクト名称
 */
define('PRODUCT_NAME', 'SITE PUBLIS');		// MICS

//  コピーライト(年)
define('COPYRIGHT_YEAR', '2003-2010');	//	SITE PUBLIS
//	コピーライト(表示文字列)
$dbMode = "";
if (defined('DEBUG_MODE')) {
	if (DEBUG_MODE) {
		$dbMode = 'use database "'.DB_TYPE.'"';
	}
}
define('COPYRIGHT_STRINGS', 'Copyright(c) '.COPYRIGHT_YEAR.', MICS Network Inc. All rights reserved. '.$dbMode);	// MICS

//	ロゴ画像
// for PUBLIS
define('PRODUCT_LOGO',			'img/logo.gif" width="100" height="40"');
//	define('PRODUCT_LOGO_LARGE',	'img/msm-logo_large.gif');	// 未使用
define('PRODUCT_LOGO_TITLE',	'img/msm-title.gif');
//	define('PRODUCT_LOGO_TITLE1_5',	'img/msm-title1-5.gif" width="150" height="15');		// 未使用(HTMLタグ削除)

/**
 * ライセンスキーファイル
 */
define('KEY_FILE', '.publisKey');

/**#@+
 * エリア
 */
define('AREA_HIDDEN', -1);
define('AREA_MAIN', 0);
define('AREA_HEADER', 1);
define('AREA_LEFT', 2);
define('AREA_RIGHT', 3);
define('AREA_FOOTER', 4);
/**#@-*/

/**
 * ユーザーID：ログインなし
 */
define('NO_LOGIN', 0);
/**
 * ユーザーID：システム管理者
 */
define('SYSTEM_ADMIN', 1);
/**
 * ユーザーID：cron実行時ユーザー
 */
define('CRON_USER', 2);
/**
 * ユーザーID：一般ユーザー
 */
define('GUEST_USER', -1);

/**
 * グループID：ログインなし
 */
define('GROUP_NO_LOGIN', 0);
/**
 * グループID：システム管理グループ
 */
define('GROUP_ADMIN', 1);
/**
 * グループID：ログインあり(一般ユーザー)
 */
define('GROUP_GUEST', 2);
/**
 * グループID：ログインあり(スタッフ)
 */
define('GROUP_STAFF', 3);



// ユーザータイプ
define('STAFF', 1);
define('GUEST', 0);

/**
 * テンポラリ
 */
define('TEMPORARY', -1);

/**
 * 公開済み
 */
define('PUBLISHED', 0);

/**
 * 承認待ち(or 公開待ち)
 */
define('WAIT', 1);


/**
 * 表示されないブロックのブロックID
 */
define('HIDDEN_BLOCK_ID', 0);
/**
 * トップブロックID
 */
define('TOP_BLOCK_ID', 1);
/**
 * サイトInfomationのブロックID
 */
define('SITE_INFO_BLOCK_ID' , 10);
/**
 * サイト初期設定の架空タイトルブロックID
 */
define('SITE_DEFAULT_BLOCK_ID' , 20);

/**#@+
 * 継承
 */
define('NO_USE', 0);
define('SITE_SETTING', 1);
define('PARENT_PAGE', 2);
define('THIS_PAGE', 3);
define('MASTER_PAGE', 4);
/**#@-*/

/**#@+
 * 権限
 */
define('NO_AUTH', 0);
define('READABLE', 100);
define('UPDATABLE', 200);
define('WRITABLE', 300);
define('ADMIN', 400);
/**#@-*/

define('HEADER_FIRST', 1);
define('SIDE_FIRST', 2);

/**#@+
 * ブロックタイプ
 */
define('TITLE_BLOCK', 2);
define('FUNCTION_BLOCK', 3);
define('BASE_BLOCK', 101);
define('NESTED_BLOCK', 102);
define('MENU_BLOCK', 111);
define('NAVIGATION_BLOCK', 112);
define('SEARCH_BLOCK', 113);
define('NEWS_DIGEST_BLOCK', 114);
define('CALENDAR_DIGEST_BLOCK', 115);
define('LOGIN_BLOCK', 116);
define('VOTE_BLOCK', 117);
define('WHATSNEW_BLOCK', 118);
define('ANCHOR_BLOCK', 119);
define('SHARE_BLOCK', 120);
define('PAGE_ITEM_BLOCK', 121);
define('NEWS_ARTICLE_BLOCK', 201);
define('CALENDAR_ARTICLE_BLOCK', 202);
define('DB_ARTICLE_BLOCK', 203);
define('BBS_ARTICLE_BLOCK', 204);
define('POPUP_BLOCK', 301);
define('PLUGIN_BLOCK', 501);
define('MOBILE_DOWNLOAD_BLOCK', 601);
/**#@-*/

/**
 * Align属性
 */
define('ALIGN_LEFT', 1);
define('ALIGN_CENTER', 2);
define('ALIGN_RIGHT', 3);

/**
 * vAlign属性
 */
define('V_ALIGN_TOP', 1);
define('V_ALIGN_CENTER', 2);
define('V_ALIGN_BOTTOM', 3);

/**
 * vAlign属性（テーブルセルでのみ使用）
 */
define('CELL_V_ALIGN_TOP', 1);
define('CELL_V_ALIGN_MIDDLE', 2);
define('CELL_V_ALIGN_BOTTOM', 3);

/**
 * 表示モード
 */
define('VIEW_MODE', 0);
/**
 * 編集モード
 */
define('EDIT_MODE', 1);

/**
 * 並べ替え方向：上へ(左へ)移動
 */
define('STEP_UP', 1);
/**
 * 並べ替え方向：下へ(右へ)移動
 */
define('STEP_DOWN', -1);

/**#@+
 * 文字スタイル
 */
define('BOLD', 1);
define('ITALIC', 2);
define('UNDERLINE', 4);
/**#@-*/

/**#@+
 * 状態
 */
/** 公開中 */
define('STAT_PUBLISHED', 0);
/** 編集中 */
define('STAT_EDIT', 1);
/** 承認待ち */
define('STAT_WAIT', 2);
/** 公開待ち */
define('STAT_APPROVED', 3);
/** 却下 */
define('STAT_REJECTED', 4);
/** ごみ箱 */
define('STAT_TRASH', 5);
/**#@-*/

/**#@+
 * 上書きチェックの戻り値
 */
/** 警告なし */
define('NO_WARNING', 0);
/** 上書き警告 */
define('WARN_OVERWRITTEN', 1);
/** 状態変更警告 */
define('WARN_CHANGED_STAT', 2);
/**#@-*/

/**#@+
 * 対応状態
 */
/** 対応待ち */
define('NO_CORRESPOND', 0);
/** 対応中 */
define('STAT_CORRESPOND', 1);
/** 対応済み */
define('STAT_CORRESPONDED', 2);
/** 未対応 */
define('STAT_DISMISS', -1);
/**#@-*/


/**
 * テキスト回り込み：左
 */
define('FLOAT_LEFT', 1);
/**
 * テキスト回り込み：右
 */
define('FLOAT_RIGHT', 2);


/**
 * ファイルタイプ：ライブラリファイル
 */
define('LIBRARY_FILE', 1);
/**
 * ファイルタイプ：バリアブルファイル
 */
define('VARIABLE_FILE', 2);

/**
 * HELPのURL
 */
define('HELP_URL', 'help/');


/**
 * ユーザーの承認状態:済み
 */
define('USER_OK', 0);
/**
 * ユーザーの承認状態:待ち
 */
define('USER_WAIT', 1);

/**#@+
 * 承認フラグ
 */
/** 承認不要 */
define('REVIEW_NO', 0);
/** 管理者承認 */
define('REVIEW_ADMIN', 1);
/** ルート承認 */
define('REVIEW_ROUTE', 2);
/**#@-*/

/**
 * SMTPポート
 */
define('SMTP_PORT', 25);

/**#@+
 * styleクラスのmakeCss()で使うフラグ
 * ※ビットマスクです。文字+背景は、STYLE_FONT+STYLE_BG=3
 */
define('STYLE_FONT', 1);
define('STYLE_BG', 2);
define('STYLE_NO_DECORATION', 4);

/**#@-*/

/**
 * ログファイル名
 */
define('LOG_FILE_ERROR', 'error.log');

/**
 * キャッシュファイル・更新タイムスタンプ保持ファイル名
 */
define('CACHE_TIME_FILE', '/tmp/___cache_time.pb');



/**
 * 却下メールフラグ
 * 過去に承認依頼メールを送ったメンバー全員
 */
define('ALL_POSTED_MEMBER', 0);
/**
 * 却下メールフラグ
 * アップデートユーザーのみ
 */
define('UPDATE_USER_ONLY', 1);

/** ファイルエラー */
define('SYNC_ERROR_FILE', 6);


// siteテーブル内の代替テキストの初期値のフラグ
define('ALT_SPECIFIED_TEXT', 0);
define('ALT_FILENAME', 1);
define('ALT_FILENAME_NO_EXT', 2);

// siteテーブル内のALTNULL警告フラグ
define('ALT_NULL_ALERT', 1);

// リダイレクトMAPファイル
define('REDIRECT_MAP_FILE', 'redirect.map');
// MAPでヒットしたときに変換される文字列
define('MAP_HIT_STRING', '!!HIT!!');

// 検索結果の参照ページ最大表示数
define('MAX_REF_PAGE', 5);

// ページ追加時のコピー元
define('PAGE_COPY_NOT_NEEDED',0);
define('PAGE_COPY_FROM_PARENT',1);
define('PAGE_COPY_FROM_BROTHER',2);
define('PAGE_COPY_FROM_END',3);
define('PAGE_COPY_FROM_TEMPLATE',4);

// ページの種類(page.link_flag)
define('NOT_LINKED_PAGE',0);
define('NORMAL_PAGE',1);
define('VIRTUAL_PAGE',2);

define('CONTENTS_LIST_TOP',1);
define('CONTENTS_LIST_UNDER',2);
define('CONTENTS_LIST_TRASH',3);


// ライブラリファイル同期のエラーコード
define('ILLEGAL_FILE_NAME', 1);
define('NO_AUTHORITY_FILE', 2);
define('DB_QUERY_ERROR', 3);

// RSSディレクトリ名
define('RSS_DIR', "rss");

// RSSファイル拡張子
define('RSS_EXT', ".xml");

// ソートしないページのsort_num
define('NO_SORT_NUM', 0);



//--------- システム構成 (site.mobile_flag) ---------------
define('SYSTEM_PC_ONLY',0);
define('SYSTEM_MOBILE_ONLY',1);
define('SYSTEM_PC_AND_MOBILE',2);

//--------- 表示コード(出力メディア)(page_revision.visible_code) ---------------
define('PC_ONLY',1);				// PCのみ
define('MOBILE_ONLY',2);			// Mobileのみ
define('PC_AND_MOBILE',3);			// PC＆Mobile
define('SMARTPHONE_ONLY',4);		// スマートフォンのみ
define('PC_AND_SMARTPHONE',5);		// PC＆スマートフォン
define('MOBILE_AND_SMARTPHONE',6);	// モバイル＆スマートフォン
define('ALL',7);					// すべて

//--------- ページ編集モード ---------------
define('EDIT_PAGE_PC'			,0);
define('EDIT_PAGE_MOBILE'		,1);
define('EDIT_PAGE_SMARTPHONE'	,2);

//--------- エイリアスモード ---------------
define('ALIAS_NORMAL',0);
define('ALIAS_HIERARCHY',1);

//--------- 階層化エイリアス拡張子 ---------------
define('ALIAS_EXTENSION', '.html');

//---------サイト内／外部フラグ ---------------
define('SHORT_CUT_IN_SITE', 1);
define('SHORT_CUT_OUT_SITE', 0);

//---------リビジョン管理対象タイプ---------------
define('REVISION_ENTITY_TYPE_PAGE', 1);
define('REVISION_ENTITY_TYPE_SHARE', 2);

//---------セッションネーム----------
define('PUBLIS_SESSION_NAME', 'sid');

//---------拡張コーナー-----------
define('EXT_ENQUETE_CORNER_NAME', '入退会アンケート');

//---------モバイルダウンロードファイル置くディレクトリ
if (defined('SITE_ROOT_DIR')) {
	define('MOBILE_LIBRARY_DIR', SITE_ROOT_DIR.'/mobile_library');
}

//---------端末ID登録有効期限----------
define('MOBILE_PREVIEW_REGIST_EXPIRE_TIME', 24);

//--------- サーバ環境変数($_SERVER)の上書き処理 ---------------
if (defined('SITE_ROOT_DIR')) {
	@include(MSM_Utils_Patch::getPatchPath(__FILE__, 'overWriteServerVariable'));
}

//--------- テンポラリテーブルデータ保持基準時間 ---------------
define('DB_TMP_PURGE_MINUTES',15);

//@todo 落ち着いたら、クラスに定義させる。
define("CARRIER_COMMON"		, 0);
define("CARRIER_DOCOMO"		, 1);
define("CARRIER_AU"			, 2);
define("CARRIER_SOFTBANK"	, 3);
define("CARRIER_WILLCOM"	, 4);
define("CARRIER_SMARTPHONE"	, 5);
define("CARRIER_OTHER"		, 99);

define('MODEL_CODE_AVAILABLE', 1);
define('MODEL_CODE_UNAVAILABLE', 2);

/* スマートフォン出力時のコンテンツ */
define('OUTPUT_PC_CONTENTS'		, 0);	// PCページを表示
define('OUTPUT_MOBILE_CONTENTS'	, 1);	// モバイルページを表示
define('SMARTPHONE_ORIGNAL'		, 2);	// スマートフォン独自の設定をする

/**
 * MMSサーバホスト名
 */
define('MMS_HOST', 'mms.micsnet.co.jp');

/**
 * MMSバージョンアップチェック用URI
 */
define('MMS_UPDATE_CHECK_URI', '/live_update/bin/update_check.php?p=');

/**
 * MMSモバイル機種情報ダウンロード用URI
 */
define('MMS_MOBILE_MODEL_DOWNLOAD', '/live_update/bin/download_mobile_model.php?p=');

/**
 * MMSモバイル機種情報アップデート用URI
 */
define('MMS_MOBILE_MODEL_UPDATE', '/live_update/bin/update_mobile_model.php?p=');

/**
 * CLOSE CURSOR処理の有効
 */
define('CLOSE_CURSOR_ENABLE', 1);

/**
 * CLOSE CURSOR処理の無効
 */
define('CLOSE_CURSOR_DISABLE', 0);

/**
 * 汎用利用：フラグON
 */
define('FLAG_ON', 1);

/**
 * 汎用利用：フラグOFF
 */
define('FLAG_OFF', 0);

?>
