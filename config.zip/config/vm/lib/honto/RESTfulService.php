<?php
/**
 * --------------------------------------------------------------------------
 * システム名 ：ハイブリッド書店システム
 * サブシステム名 ：AP基盤
 * 機能名 ：共通フレームワーク
 * c 2011 Dai Nippon Printing Co.,Ltd. All rights reserved.
 * --------------------------------------------------------------------------
 * @package Honto
 */

require_once 'honto/ApplicationLogger.php';
//require_once 'Zend/Http/Client.php';
require_once 'honto/FaultMapper.php';
require_once 'honto/Utils.php';
require_once 'honto/Keys.php';
require_once 'honto/SystemParameters.php';
require_once 'honto/ResourceCacheDnp.php';
require_once 'honto/DumpPage.php';

/**
 * JAX-RSのサービスを呼び出すためのクラス。
 *
 * @author tanaka.kenichiro
 */
class Honto_RESTfulService
{
    private $_uri;

    private $_client;

    private $_header;

    private $_logger;

    private $_proxyConfig;

    private $_memcached;

    private $ownerName;

    private $_timout;

    /** ダンプ出力用オブジェクト */
    private $dumpPage = null;
    private $dump = null;

    /**
     * コンストラクタ。新規サービスアクセスオブジェクトを生成する。
     * @param object $owner オブジェクトのオーナー。通常は $this を与える。
     * @param string $uri 接続URI。Honto_UriBuilder::createResourcePath() で生成したものを想定。
     */
    public function __construct($owner, $uri, $timeout = SystemParameters::REST_SERVICE_TIMEOUT)
    {
        $this->_uri = $uri;
        $this->_timeout = $timeout;

        $this->_logger = new Honto_ApplicationLogger(get_class($owner));

        // 固定ヘッダの設定
        $this->setRequestHeader('Content-Type', 'application/json');
        $this->setRequestHeader('Accept', 'application/xml; charset="UTF-8"');
        $this->setRequestHeader(HeaderKey::SSID, Honto_Utils::getSession(SessionKey::SSID));


        $this->_proxyConfig = array();

        $this->_memcached = new Honto_ResourceCacheDnp($uri);
        $this->ownerName = get_class($owner);
        $this->dumpPage = new Honto_DumpPage();
    }

    /**
     * プロキシ設定（使用しません）
     */
    public function setProxy($host, $port)
    {
    }

    /**
     * リソースに対するリクエストヘッダを設定する。
     * リクエストを送る前に設定する必要がある。
     * @param string $name 値を設定するリクエストヘッダ
     * @param string $value ヘッダ値
     */
    public function setRequestHeader($name, $value)
    {
        //$this->_client->setHeaders($name, $value);
        $this->_header[$name] = $value;
    }

    /**
     * リソースに対するリクエストヘッダを設定する。
     * リクエストを送る前に設定する必要がある。
     * @param array $headers リクエストヘッダとその値の連想配列
     */
    public function setRequestHeaders($headers)
    {
        array_merge($this->_header, $headers);
    }

    /**
     * レスポンスヘッダの値を取得する。
     * 当然リクエストを送った後でないと取得できない。
     * @param string $key 値を取得したいレスポンスヘッダ。
     * @return string 指定したレスポンスヘッダの値。指定したヘッダがない場合は null が返る。
     */
    public function getResponseHeader($key)
    {
        return $this->_client->getLastResponse()->getHeader($key);
    }

    /**
     * リソースに対してPOSTメソッドでアクセスする。
     * @param array $body リクエストボディに用いる連想配列。JSONとして送信される。
     * @return SimpleXMLElement レスポンスボディ（XMLで返る前提）
     */
    public function post($body = null)
    {
        //$result = $this->request(Zend_Http_Client::POST, $body);
        $result = $this->request('POST', $body);

		if ( class_exists('DumpDebug') ) {
			$this->dump['api']['date'] = date('Y/m/d H:i:s');
			$this->dump['api']['plugin'] = (DumpDebug::$nowPlugin) ? DumpDebug::$nowPlugin : $this->ownerName;
			$this->dump['api']['api_url'] = $this->_uri;
			$this->dump['api']['xml'] = DumpDebug::xml_object_to_string($result);
			DumpDebug::debug_save($this->dump);
		}
        return $result;
    }

    /**
     * リソースに対してGETメソッドでアクセスする。
     * 同一ページ内で同じリソースURIに対する複数のGETはキャッシュされ、２回目以降はキャッシュが利用される。
     * 引数に false を渡すとキャッシュを使わずに新たにリソースを取得しなおす。
     * @param bool $useCache リソースキャッシュを利用するかどうか。デフォルトでは利用する。
     * @return SimpleXMLElement レスポンスボディ（XMLで返る前提）
     */
    public function get($useCache = true) {
		if (Honto_Utils::getSession('dev_cache') == 'off') {
			$useCache = false;
		}


        if ($useCache && $this->pageCacheExists($this->_uri)) {

            $result = $this->getPageCache($this->_uri);
            $this->_logger->debug('RESTful: Result from PageCache.' . $this->_uri);

			$mode = 'PageCache';
        } else {

            $result = $this->_memcached->get();

            if ($result == null) {
                // リソースから取得後ページキャッシュに保存
                // $result = $this->request(Zend_Http_Client::GET);
                $result = $this->request('GET');
                $this->putPageCache($this->_uri, $result);
                // memcachedに保存
                $this->_memcached->put($result);
                $this->_logger->debug('RESTful: Result from Java Resource.' . $this->_uri);
				$mode = 'Resource';
            } else {
                $this->_logger->debug('RESTful: Result from Memcached.' . $this->_uri);

                // [PERFLOG] start
                $this->_logger->info('[PERFLOG] '.$psid.'   '.$ssid.'   '.$memid.'  '.$xupsubno.'   [REST]  [Memcached] '.$this->_uri.' '.$rest_proc.'  sec');
                // [PERFLOG] end

				$mode = 'Memcached';
            }
        }
		if ( class_exists('DumpDebug') ) {
			$this->dump['api']['date'] = date('Y/m/d H:i:s');
			$this->dump['api']['plugin'] = (DumpDebug::$nowPlugin) ? DumpDebug::$nowPlugin : $this->ownerName;
			$this->dump['api']['api_url'] = $this->_uri;
			$this->dump['api']['from'] = $mode;
			$this->dump['api']['xml'] = DumpDebug::xml_object_to_string($result);
			DumpDebug::debug_save($this->dump);
		}
        return $result;
    }

    /**
     * リソースに対してGETメソッドでアクセスする。キャッシュは利用せず、必ずRESTfulサービスを呼び出す。
     * @return SimpleXMLElement レスポンスボディ（XMLで返る前提）
     */
    public function getOriginal() {

        $result = $this->request('GET');
        $this->_logger->debug('RESTful: Result from Java Resource.' . $this->_uri);

        // ページキャッシュに保存
        $this->putPageCache($this->_uri, $result);
        // Memcachedに保存。キャッシュ可能なリソースか否かはこの先で判定
        $this->_memcached->put($result);

        return $result;
    }

    /**
     * リクエストの実装.
     */
    private function request($method, $body = null)
    {
        $this->_logger->debug('RESTful: ' . $method . ' ' . $this->_uri);

        $this->_client = curl_init($this->_uri);
        // 接続の試行を待ち続ける秒数
        curl_setopt($this->_client, CURLOPT_CONNECTTIMEOUT, SystemParameters::CURLOPT_CONNECTTIMEOUT_VALUE);
        // 関数の実行にかけられる時間の最大値
        curl_setopt($this->_client, CURLOPT_TIMEOUT, $this->_timeout);
        // 詳細情報出力をOFF
        curl_setopt($this->_client, CURLOPT_RETURNTRANSFER, 1);

		curl_setopt($this->_client, CURLOPT_PROXY, 'http://210.133.104.126:80');

        // これをtrueにするとコンテンツにヘッダが含まれます
        //        curl_setopt($this->_client, CURLOPT_HEADER, 1);
        // これをtrueにすると詳細な情報が標準出力に出力されます。
        //        curl_setopt($this->_client, CURLOPT_VERBOSE, 1);
        //        curl_setopt($this->_client, CURLINFO_HEADER_OUT, 1);


        if (isset($body)) {
            // $this->_client->setRawData(json_encode($body));
            // リクエストbodyにjson_encodeできない形式が含まれる場合の処理を追加12.04.21
            $jsonBody = json_encode($body);
            $json_error = json_last_error();
            if ($json_error != JSON_ERROR_NONE ) {

                // body出力
                $this->_logger->info('JSON ERROR BODY:' .PHP_EOL . $this->_logger->createMaskParameter($body));

                // encode時にエラーが発生した場合は、不正なリクエストとみなし、例外を発生させる
                throw new Exception('[JSON ENCODE ERROR] PHPエラーコード＝' . $json_error);
            }
            curl_setopt($this->_client, CURLOPT_POSTFIELDS, $jsonBody);
        }

        // POSTをセット
        if ($method == "POST") {
            curl_setopt($this->_client, CURLOPT_POST, 1);
        }

        // headerは連想配列から　キー：値に変換
        $headers = array();
        foreach ($this->_header as $key => $value) {
            $headers[] = $key . ': ' . $value;
        }

        // $response = $this->_client->request($method);

        // headerのセット
        curl_setopt($this->_client, CURLOPT_HTTPHEADER, $headers);

        $rest_start = microtime(true);

        // コール
        $response = curl_exec($this->_client);

        // curlでエラーが発生した場合は、例外を出力。
        if (curl_errno($this->_client)) {
            $curlErrno = curl_errno($this->_client);
            $curlErr = curl_error($this->_client) . '  [uri]' . $this->_uri;
            curl_close($this->_client);
            throw new Exception($curlErr, $curlErrno);
        }

        // $resStatus = $response->getStatus();
        // ステータスの取得
        $resStatus = curl_getinfo($this->_client, CURLINFO_HTTP_CODE);

        $rest_end = microtime(true);
        $rest_proc = substr(sprintf('%f', $rest_end - $rest_start), 0, 5);

        // クローズ
        curl_close($this->_client);

        // $headers = $response->getHeaders();
        //$this->_logger->debug('headers: ' . (string)print_r($headers, true));
        // $this->_logger->debug('status: ' . $response->getStatus());
        $this->_logger->debug('status: ' . $resStatus);
        /*if (array_key_exists('Content-length', $headers)) {
        $this->_logger->debug('headers[Content-length]: ' . $headers['Content-length']);
        }*/

		$this->dump['api']['headers'] = $headers;
		$this->dump['api']['method'] = $method;
		$this->dump['api']['param'] = $body;
		$this->dump['api']['time'] = $rest_proc;
		$this->dump['api']['status'] = $resStatus;
		//$this->dump['api']['backtrace'] = debug_backtrace();

        // @$resBody = simplexml_load_string($response->getBody());
        // headerオフ設定の場合は、content部分のみが$responseにセットされる
        @$resBody = simplexml_load_string($response);

        // libxmlエラーを取得する
        $xml_errors = libxml_get_errors();

        // libxmlエラーハンドラをクリアする
        libxml_clear_errors();

        // リソースAPIの戻り情報をログ出力します。
        if ($this->dumpPage->issetRestLog()) {
            //$this->_logger->debug('status: ' . $response->getStatus());
            $this->_logger->debug('status: ' . $resStatus);
            // $this->_logger->debug('body: ' . $response->getBody());
            $this->_logger->debug('body: ' . $response);
        }
        if (200 <= $resStatus && $resStatus < 300) {
            // エラーが発生していた場合、ログに蓄積
            if (!$resBody && count($xml_errors) > 0) {
                $xml_error_message = '';
                foreach( $xml_errors as $xml_error ){
                  $xml_error_message .= $xml_error->message;
                }

                // simplexml_load_string でエラーとなった場合は、WARNを出力
                $this->_logger->log(Honto_ApplicationLogger::WARN, Honto_MessageList::APS_WRN_1001,
                    array('{0}' => 'XML ERROR:' . $method . ' ' . $this->_uri . ' '  . $resStatus. ' ' . $xml_error_message));
            }

            return $resBody;

        } else {
            $this->_logger->info('REST ERROR:' . $method . ' ' . $this->_uri . ' '  . $resStatus . ' ' . $response);

            if ($resBody) {
                Honto_FaultMapper::checkFault($resStatus, $resBody);
            }
            // ダンプ出力確認
            if ($this->dumpPage->issetDump()) {

                $dataArray['Plugin Name'] = $this->ownerName;
                $dataArray['Java Resource'] = $this->_uri;
                $dataArray['Java Resource status'] = $resStatus;
                $dataArray['Java Resource body'] = $resBody;
                $dataArray['$_SESSION'] = $_SESSION;
                $dataArray['$_GET'] = $_GET;
                $dataArray['$_POST'] = $_POST;

                $this->dumpPage->dump('REST ERROR', $dataArray);
            } else {
                throw new Exception($resBody, $resStatus);
            }
        }
    }

    private static $pageCache = array();

    public static function pageCacheExists($uri)
    {
        return isset(self::$pageCache[$uri]);
    }

    public static function getPageCache($uri)
    {
        return self::$pageCache[$uri];
    }

    public static function putPageCache($uri, $response)
    {
        self::$pageCache[$uri] = $response;
    }

}
