<?php
/**
 * --------------------------------------------------------------------------
 * システム名 ：ハイブリッド書店システム
 * サブシステム名 ：AP基盤
 * 機能名 ：共通フレームワーク
 * © 2011 Dai Nippon Printing Co.,Ltd. All rights reserved.
 * --------------------------------------------------------------------------
 * @package Honto
 */

//
// ローカル環境でもデバッグできるよう、SITE PUBLIS の一部機能をスタブとして用意した。
//
// @author tanaka.kenichiro
//

if (defined('SITE_ROOT_DIR')) {
    // SITE PUBLIS 環境

    define('LIBRARY_BASE_DIR', '');

    // /etc/hosts に appserver のエントリを追記しておく。
    // appserverのIPアドレスは、開発者用のローカル SITE PUBLIS (VM) では自分の開発マシンのIPアドレスを、
    // 結合用 SITE PUBLIS では対応するAPサーバのIPアドレスを指定しておく。
    //define('SERVICE_BASE_URI', 'http://appserver:8080/api');
    define('SERVICE_BASE_URI', 'http://172.17.196.173:8080/api');

    define('AJAX_CALL', LIBRARY_BASE_DIR . '/view_interface.php');

} else {
    // ローカルデバッグ環境

    require_once 'Smarty/Smarty.class.php';

    define('SITE_PUKLIS', true);
    define('SITE_ROOT_DIR', '.');
    define('LIBRARY_BASE_DIR', '.');

    define('SERVICE_BASE_URI', 'http://localhost:8080/api');

    define('AJAX_CALL', 'show_ajax.php');

    // MSM/Consts.php より必要なものを抜粋
    define('PUBLISHED', 0);
    define('WAIT', 1);

    define('VIEW_MODE', 0);
    define('EDIT_MODE', 1);

    define('CARRIER_COMMON', 0);
    define('CARRIER_DOCOMO', 1);
    define('CARRIER_AU', 2);
    define('CARRIER_SOFTBANK', 3);
    define('CARRIER_WILLCOM', 4);
    define('CARRIER_SMARTPHONE', 5);
    define('CARRIER_OTHER', 99);

    define('PC_ONLY', 1);
    define('MOBILE_ONLY', 2);
    define('SMARTPHONE_ONLY', 4);

    define('NO_LOGIN', 0);
    define('STAFF', 1);
    define('GUEST', 0);
    /**
     * SITE PUBLIS のローカルデバッグ用ダミークラス。
     *
     * @author tanaka.kenichiro
     */
    abstract class PLUGIN_Smarty
    {
        private $smarty;

        protected $blockId;

        protected $description;

        protected $smartyParameters;

        protected function __construct($blockId) {
            $this->smartyParameters = array();
            $this->blockId = $blockId;
        }

        /** 利用するテンプレート数。MultiTemplatePluginBase を継承するクラスでは定義しなおす。 */
        protected $numTemplates = 1;

        /**
         * 現在選択中のテンプレート番号。MultiTemplatePluginBase で設定する。
         * @return int 選択中のテンプレート番号（1-origin）。
         */
        protected function getTemplateIdx() {
            return 1;
        }

        protected function getDefaultParams($param) {
            return array();
        }

        protected function fetch(&$db, &$currPage, $mode) {
            if (!isset($this->smarty)) {
                $dir = 'smarty/';
                $this->smarty = new Smarty();
                $this->smarty->template_dir = $dir . 'templates/';
                $this->smarty->compile_dir = $dir . 'templates_c/';
                $this->smarty->config_dir = $dir . 'configs/';
                $this->smarty->cache_dir = $dir . 'cache/';

                // ローカルプラグインディレクトリの追加
                array_push($this->smarty->plugins_dir,  $dir . 'plugins/');

            }
            foreach ($this->smartyParameters as $key => $value) {
                $this->smarty->assign($key, $value);
            }
            $pluginName = preg_replace('/^PLUGIN_/', '', get_class($this));
            $prefix = strtolower(substr($pluginName, 0, 3));
            $postfix = '';
            if ($this->numTemplates > 1) {
                $postfix = '_' . $this->getTemplateIdx();
            }
            return $this->smarty->fetch("{$prefix}/{$pluginName}{$postfix}.tpl");
        }

        public function getBlockId() {
            return $this->blockId;
        }

        public function getPageBlockId() {
            return $this->blockId;
        }

        public function getPageId() {
            return 0;
        }

        public function getRevision() {
            return PUBLISHED;
        }

        protected function load($db) {
            //EMPTY
        }

        public function getDescription() {
            return $this->description;
        }

        protected function loadParameters($db = null) {
            return array();
        }

        protected function loadCommonParameters($db = null) {
            return array();
        }

        public function isPcVisible() {
            return true;
        }

        public function isMobileVisible() {
            return false;
        }

        public function isSmartPhoneVisible() {
            return false;
        }
    }

    /**
     * SITE PUBLIS のローカルデバッグ用ダミークラス。
     *
     * @author nakagawa.akihiko
     */
    class MSM_SmartyManager
    {
        /**
         * テンプレートパスを取得
         *
         * @param $_templateId テンプレートID
         * @return テンプレートのフルパス
         */
        public function getTemplatePath($_templateId) {
            return $_templateId;
        }
    }

    /**
     * SITE PUBLIS のローカルデバッグ用ダミークラス。
     *
     * @author nakagawa.akihiko
     */
    interface MSM_PartialCache_Interface
    {
        /**
         * @brief 初期化メソッド
         * @param $_params 初期化用のパラメータ
         */
        public function initialize($_params);

        /**
         * @brief コンテンツダウンロードメソッド
         */
        public function loadContents();

        /**
         * @brief コンテンツ取得(表示)メソッド
         * @return HTML
         */
        public function getContents();

        /**
         * @brief タグに埋め込むパラメータ
         * @return パラメーターを格納した連想配列
         */
        public function getParameters();
    }

    /**
     * SITE PUBLIS のローカルデバッグ用ダミークラス。
     *
     * @author noguchi.hideki
     */
    interface MSM_PartialCache_HeadInterface
    {
    	/**
    	 * @brief ヘッダコンテンツ取得メソッド
    	 * @return string ヘッダHTML
    	 */
    	public function getHeadContents();
    }

    class MSM_DBPool
    {
        private static $S;

        public static function &getPoolingConnection() {
            // リファレンスを返すため変数にストア。
            self::$S = new self();
            return self::$S;
        }
    }

    class MSM_Page
    {
        private static $S;

        public static function &getNoCachePage($pageId, $revision) {
            // リファレンスを返すため変数にストア。
            self::$S = new self();
            return self::$S;
        }

        public function getPageId() {
            return 0;
        }
    }

    class MSM_Utils_Alias
    {
        public static function getAliasPath(&$db, $pageId) {
            return substr(Honto_SitePath::TOP_00_001, 1);
        }
    }

    class MSM_MobileUtils {
        public static function getOutputMediaType() {
            return PC_ONLY;
        }

        public static function getOriginalOutputMediaType() {
            return PC_ONLY;
        }

        public static function getUserCarrier() {
            return CARRIER_OTHER;
        }
    }

    class MSM_Utils_User
    {
        public static function getUserId() {
            return NO_LOGIN;
        }

        public static function getUserType() {
            return GUEST;
        }
    }

    class MSM_MobileSession
    {
        public function regenerateSessionId( $_deviceId ) {
            return true;
        }
    }

    class MSM_Device {

    	public static function getDeviceID() {
    		return  '';
    	}
    }
}
